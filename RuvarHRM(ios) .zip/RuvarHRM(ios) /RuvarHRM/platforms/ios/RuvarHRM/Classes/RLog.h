//
//  RLog.h
//  ruvaroa
//
//  Created by ruvar on 15/3/11.
//
//

#ifndef ruvaroa_RLog_h
#define ruvaroa_RLog_h


#endif
@interface RLog
-(void)TestString:(NSString*)stringvalue RString:(NSString*)rstring Times:(int)t;
@end
