
function consolelog(msg){
    console.log(msg);
    return ;
}










